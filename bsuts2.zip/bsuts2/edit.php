<?php
// include database connection file
include_once("config.php");

// Check if form is submitted for user update, then redirect to homepage after update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama_karya = $_POST['nama_karya'];
    $tahun = $_POST['tahun'];
    $artis = $_POST['artis'];
    $bid = $_POST['bid'];
    $jenis_karya = $_POST['jenis_karya'];
    $instansi = $_POST['instansi'];
    $deskripsi = $_POST['deskripsi'];

    // update user data
    $result = mysqli_query($mysqli, "UPDATE karya SET nama_karya='$nama_karya',tahun='$tahun',artis='$artis',bid='$bid',jenis_karya='$jenis_karya',instansi='$instansi',deskripsi='$deskripsi' WHERE id=$id");

    // Redirect to homepage to display updated user in list
    header("Location: indeks.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];

// Fetech user data based on id
$result = mysqli_query($mysqli, "SELECT * FROM karya WHERE id=$id");

while ($user_data = mysqli_fetch_array($result)) {
    $id = $user_data['id'];
    $nama_karya = $user_data['nama_karya'];
    $tahun = $user_data['tahun'];
    $artis = $user_data['artis'];
    $bid = $user_data['bid'];
    $jenis_karya = $user_data['jenis_karya'];
    $instansi = $user_data['instansi'];
}
?>
<html>

<head>
    <title>Edit User Data</title>
</head>

<body>
    <a href="indeks.php">Home</a>
    <br /><br />

    <form name="update_user" method="post" action="edit.php">
        <table border="0">
            <tr>
                <td>ID</td>
                <td><input type="text" name="id" value=<?php echo $id; ?>></td>
            </tr>
            <tr>
                <td>Nama Karya</td>
                <td><input type="text" name="nama_karya" value=<?php echo $nama_karya; ?>></td>
            </tr>
            <tr>
                <td>Tahun</td>
                <td><input type="text" name="tahun" value=<?php echo $tahun; ?>></td>
            </tr>
            <tr>
                <td>Seniman</td>
                <td><input type="text" name="artis" value=<?php echo $artis; ?>></td>
            </tr>
            <tr>
                <td>BID (IDR)</td>
                <td><input type="text" name="bid" value=<?php echo $bid; ?>></td>
            </tr>
            <tr>
            <td>Jenis Karya</td>
            <td>
            <input type="checkbox" name="jenis_karya" value="<?php echo $jenis_karya; ?>">Fotografi<br>
            <input type="checkbox" name="jenis_karya" value="<?php echo $jenis_karya; ?>">Seni Lukis<br>
            </td>
        </tr>
        <tr>
            <td>Instansi</td>
            <td>
            <select name="instansi">
                <option value="<?php echo $instansi; ?>>">ISI Surakarta</option>
                <option value="<?php echo $instansi; ?>>">ITS PKU Muhammadiyah Surakarta</option>
                <option value="<?php echo $instansi; ?>>">Universitas Sebelas Maret</option>
                <option value="<?php echo $instansi; ?>>">Universitas Muhammadiyah Surakarta</option>
            </select>
            </td>
        </tr>
        <tr>
            <td>Deskripsi Karya</td>
            <td>
            <textarea name="deskripsi" rows="8" col="200" value="<?php echo $deskripsi; ?>>"></textarea>
            <br><br>
            </td>
        </tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id']; ?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>

</html>