<html>
<head>
    <title>Add karya</title>
</head>

<link rel="stylesheet" href="style.css">

<body>
<a href="indeks.php" class="signup-section">Go to Home</a>
<br/><br/>

<form action="add.php" method="post" name="form1">
    <table width="25%" border="0">
        <tr>
            <td>ID</td>
            <td><input type="text" name="id" required="required" /></td>
        </tr>
        <tr>
            <td>Nama Karya</td>
            <td><input type="text" name="nama_karya"></td>
        </tr>
        <tr>
            <td>tahun Pembuatan (Finish)</td>
            <td><input type="date" name="tahun"></td>
        </tr>
        <tr>
            <td>Nama Seniman</td>
            <td><input type="text" name="artis"></td>
        </tr>
        <tr>
            <td>BID (IDR)</td>
            <td><input type="text" name="bid"></td>
        </tr>
        <tr>
            <td>Jenis Karya</td>
            <td>
            <input type="checkbox" name="jenis_karya" value="Fotografi">Fotografi<br>
            <input type="checkbox" name="jenis_karya" value="Seni Lukis">Seni Lukis<br>
            </td>
        </tr>
        <tr>
            <td>Instansi</td>
            <td>
            <select name="instansi">
                <option value="ISI">ISI Surakarta</option>
                <option value="ITS">ITS PKU Muhammadiyah Surakarta</option>
                <option value="UNS">Universitas Sebelas Maret</option>
                <option value="UMS">Universitas Muhammadiyah Surakarta</option>
            </select>
            </td>
        </tr>
        <tr>
            <td>Deskripsi Karya</td>
            <td>
            <textarea name="deskripsi" rows="8" col="200"></textarea>
            <br><br>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="Submit" value="Add"></td>
        </tr>
    </table>
</form>

<?php
// Check If form submitted, insert form data into users table.
if(isset($_POST['Submit'])) {
    $id = $_POST['id'];
    $nama_karya = $_POST['nama_karya'];
    $tahun = $_POST['tahun'];
    $artis= $_POST['artis'];
    $bid = $_POST['bid'];
    $jenis_karya = $_POST['jenis_karya'];
    $instansi = $_POST['instansi'];
    $deskripsi = $_POST['deskripsi'];

    // include database connection file
    include_once ("config.php");

    // Insert user data into table
    $result = mysqli_query($mysqli, "INSERT INTO karya(id,nama_karya,tahun,artis,bid,jenis_karya,instansi,deskripsi) VALUES('$id','$nama_karya','$tahun','$artis','$bid','$jenis_karya','$instansi','$deskripsi')");

    // Show message when user added
    echo "User added successfully. <a href='indeks.php'>View Daftar Karya</a>";
}
?>

</body>
</html>