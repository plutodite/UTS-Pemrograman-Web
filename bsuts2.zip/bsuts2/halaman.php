
<style type="text/css">
    .header{
        background-color: darkcyan;
    }
</style>
<?php

include_once("config.php");


$result = mysqli_query($mysqli, "SELECT * FROM karya ORDER BY id DESC");
?>

<html>
<head>
    <title>exhib</title>
</head>

<body>
<b>Daftar Karya dan Bid</b><br>
<a href="add.php">Tambah Karya</a><br/><br/>

<table width='80%' border=1>

    <tr class="header">
        <th>No</th> <th>ID<t/h> <th>Nama Karya</th> <th>Tahun Pembuatan</th> <th>Seniman</th> <th>Harga (Rp)</th> <th>Jenis Karya</th> <th>Instansi</th> <td>Deskripsi</td> <th>Aksi</th>
    </tr>
    <?php
    $i=1;
    while($user_data = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>".$i."</td>";
        echo "<td>".$user_data['nama_karya']."</td>";
        echo "<td>".$user_data['tahun']."</td>";
        echo "<td>".$user_data['artis']."</td>";
        echo "<td>".$user_data['bid']."</td>";
        echo "<td>".$user_data['jenis_karya']."</td>";
        echo "<td>".$user_data['instansi']."</td>";
        echo "<td>".$user_data['deskripsi']."</td>";
        echo "<td><a href='edit.php?id=$user_data[id]'>Edit</a> | <a href='delete.php?id=$user_data[id]'>Delete</a></td></tr>";
        $i++;
    }
    ?>
</table>
</body>

</html>